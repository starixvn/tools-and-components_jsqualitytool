module.exports =
{
	reporter: function (results)
	{
		"use strict";

		var files = {},
		out = [],
		pairs = {
			"&": "&amp;",
			'"': "&quot;",
			"'": "&apos;",
			"<": "&lt;",
			">": "&gt;"
		},
		file, i, issue;

		function encode(s) {
			for (var r in pairs) {
				if (typeof(s) !== "undefined") {
					s = s.replace(new RegExp(r, "g"), pairs[r]);
				}
			}
			return s || "";
		}


		results.forEach(function (result) {
			result.file = result.file.replace(/^\.\//, '');
			if (!files[result.file]) {
				files[result.file] = [];
			}
			files[result.file].push(result.error);
		});

		//out.push("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
		out.push("<div>");

		for (file in files) {
			out.push('<ul>' + file);
			for (i = 0; i < files[file].length; i++) {
				issue = files[file][i];
				out.push( '<li>' + issue.line + '</li>' +
					 '<li>' + issue.character + '</li>' +
					'<li>' + encode(issue.reason) + '</li>' +
					'<li>' + encode(issue.evidence) + '</li>');
			}
			out.push('</ul>');
		}

		out.push("</div>");

		process.stdout.write(out.join("\n") + "\n");
	}
};
